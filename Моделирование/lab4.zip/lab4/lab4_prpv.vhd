LIBRARY IEEE;
USE IEEE.STD_LOGIC_1164.ALL;

ENTITY PRPV IS
    PORT(
        X1, X2, X3, X4 : IN  STD_LOGIC;
        write          : IN  STD_LOGIC;
        reset          : IN  STD_LOGIC;   -- ??? ??? "_n"
        read           : IN  STD_LOGIC;
        Q1, Q2, Q3, Q4 : OUT STD_LOGIC
    );
END PRPV;

ARCHITECTURE BEHAV OF PRPV IS
    SIGNAL reg_int : STD_LOGIC_VECTOR(3 DOWNTO 0);
BEGIN
    PROCESS(write, reset)
    BEGIN
        IF reset = '0' THEN                -- ??? ? ?????: ???????? '0'
            reg_int <= (OTHERS => '0');
        ELSIF write'EVENT AND write = '1' THEN
            reg_int(0) <= X1;
            reg_int(1) <= X2;
            reg_int(2) <= X3;
            reg_int(3) <= X4;
        END IF;
    END PROCESS;

    Q1 <= reg_int(0) AND read;
    Q2 <= reg_int(1) AND read;
    Q3 <= reg_int(2) AND read;
    Q4 <= reg_int(3) AND read;
END BEHAV;
